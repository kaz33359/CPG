@extends('home.layouts.layout')

@section('content')
<!-- Inner Page Breadcrumb -->
		<section class="inner_page_breadcrumb csv1">
			<div class="container">
				<div class="row">
					<div class="col-xl-6 offset-xl-3 text-center">
						<div class="breadcrumb_content">
							<h4 class="breadcrumb_title">Blog</h4>
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>

								<li class="breadcrumb-item active" aria-current="page">Blog</li>
							</ol>
						</div>
					</div>
				</div>
			</div>
		</section>

		<!-- Our Team Members -->
		<section class="our-team pb40">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-lg-8 col-xl-9">
						<div class="row">
							<div class="col-lg-12">
								<div class="courses_single_container">
									<div class="cs_row_one">
										<div class="cs_ins_container">
											<div class="cs_instructor">


											</div>
											<h3 class="cs_title">IOSH Level 3 Certifications Training </h3>
											<ul class="cs_review_seller">
												<li class="list-inline-item"><a href="#Overview"><span>Read</span></a>
												</li>
												<!--<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
												<!--<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
												<!--<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
												<!--<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
												<!--<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
												<!--<li class="list-inline-item"><a href="#">4.5 </a></li>-->
											</ul>

											<div class="courses_big_thumb">
												<div class="thumb">
													<img src="images/courses/a5.jpg">
												</div>
											</div>
										</div>
									</div>
									<div id="Overview" class="cs_row_two">
										<div class="cs_overview">
											<h4 class="title">Overview</h4>
											<h4 class="subtitle">Course Description</h4>
											<p class="mb30">The IOSH Level 3 Certificate in Safety and Health for
												Business is a globally recognised qualification that provides an
												understanding of safety and health in a business context. Our
												qualification is well known worldwide to global businesses and supply
												chains, so your qualification will apply to all markets. As a learner
												you will gain technical knowledge and skills, as well as effective
												techniques to apply that knowledge in the business. Our assessments are
												practical and based on real-life scenarios that can be applied in the
												workplace while studying this qualification.</p>
											<p class="mb20">Our system gives you access to a virtual tutor who can guide
												you with any questions you might have along the way.</p>
											<p>Once you achieve this qualification, it will give you greater credibility
												and confidence when talking to senior management about safety and health
												in business</p>

											<p></p>


										</div>
									</div>




								</div>

							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-12">
							<h3 class="r_course_title">Related</h3>
						</div>
						<div class="col-lg-6 col-xl-4">
							<div class="top_courses">
								<div class="thumb">
									<img class="img-whp" src="images/courses/SMS.jpg" alt="2.jpg">
									<div class="overlay">
										<div class="tag">Related</div>
										<div class="icon"><span class="flaticon-like"></span></div>
										<a class="tc_preview_course" href="b6.html">View</a>
									</div>
								</div>
								<div class="details">
									<div class="tc_content">
										<p>CPG</p>
										<h5>Safety Manpower Solutions</h5>
										<!--<ul class="tc_review">-->
										<!--	<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
										<!--	<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
										<!--	<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
										<!--	<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
										<!--	<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
										<!--	<li class="list-inline-item"><a href="#">(6)</a></li>-->
										<!--</ul>-->
									</div>
									<div class="tc_footer">
										<ul class="tc_meta float-left">
											<!--<li class="list-inline-item"><a href="#"><i class="flaticon-profile"></i></a></li>-->
											<li class="list-inline-item"><a href="#"><i
														class="flaticon-comment"></i></a></li>
											<li class="list-inline-item"><a href="b6.html">Click here to Know More </a>
											</li>
											<!--<li class="list-inline-item"><a href="#">25</a></li>-->
										</ul>
										<div class="tc_price float-right">>></div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-6 col-xl-4">
							<div class="top_courses">
								<div class="thumb">
									<img class="img-whp" src="images/courses/FPS.jpg" alt="4.jpg">
									<div class="overlay">
										<div class="tag">Related</div>
										<div class="icon"><span class="flaticon-like"></span></div>
										<a class="tc_preview_course" href="b1.html">View</a>
									</div>
								</div>
								<div class="details">
									<div class="tc_content">
										<p>CPG</p>
										<h5>Fire Protection System</h5>
										<!--<ul class="tc_review">-->
										<!--	<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
										<!--	<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
										<!--	<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
										<!--	<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
										<!--	<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
										<!--	<li class="list-inline-item"><a href="#">(6)</a></li>-->
										<!--</ul>-->
									</div>
									<div class="tc_footer">
										<ul class="tc_meta float-left">
											<!--<li class="list-inline-item"><a href="#"><i class="flaticon-profile"></i></a></li>-->
											<li class="list-inline-item"><a href="#"><i
														class="flaticon-comment"></i></a></li>
											<li class="list-inline-item"><a href="b1.html">Click here to Know More </a>
											</li>
											<!--<li class="list-inline-item"><a href="#">25</a></li>-->
										</ul>
										<div class="tc_price float-right">>></div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-6 col-xl-4">
							<div class="top_courses">
								<div class="thumb">
									<img class="img-whp" src="images/courses/3.jpg" alt="3.jpg">
									<div class="overlay">
										<div class="tag">Top Course</div>
										<div class="icon"><span class="flaticon-like"></span></div>
										<a class="tc_preview_course" href="c3.html">Preview Course</a>
									</div>
								</div>
								<div class="details">
									<div class="tc_content">
										<p>CPG</p>
										<h5>OTHM Level 6 Diploma</h5>
										<!--<ul class="tc_review">-->
										<!--	<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
										<!--	<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
										<!--	<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
										<!--	<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
										<!--	<li class="list-inline-item"><a href="#"><i class="fa fa-star"></i></a></li>-->
										<!--	<li class="list-inline-item"><a href="#">(6)</a></li>-->
										<!--</ul>-->
									</div>
									<div class="tc_footer">
										<ul class="tc_meta float-left">
											<!--<li class="list-inline-item"><a href="#"><i class="flaticon-profile"></i></a></li>-->
											<li class="list-inline-item"><a href="#"><i
														class="flaticon-comment"></i></a></li>
											<li class="list-inline-item"><a href="c3.html">Click here to Know More </a>
											</li>
											<!--<li class="list-inline-item"><a href="#">25</a></li>-->
										</ul>
										<div class="tc_price float-right">>></div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>
	</div>
	</section>
@endsection